import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// import {RequestOptions } from '@angular/http';
import { observable, throwError, Observable, of } from 'rxjs';
import { catchError, retry, tap ,map} from 'rxjs/operators';
import { comics } from '../model/comice.model';

@Injectable()
export class ComicService {
    private apiURL: string = "https://cors-anywhere.herokuapp.com/https://comicvine.gamespot.com/api/characters/?api_key=f49296cd3e8ed1f3e52e9616a0a4d681e10d178f&format=json";
    private headers;
    comics: comics[]

    constructor(private http: HttpClient) {

    }

    getComics(option: string, filter: string): Observable<comics[]> {
      
        if (option == "Detail") {
            this.apiURL = this.apiURL + "&filter=id:" + filter;
        } else if (option == "Search") {
            this.apiURL = this.apiURL + "&filter=name:" + filter;
        }

        this.headers = new HttpHeaders();
        this.headers = this.headers
            .set('Access-Control-Allow-Headers', 'Content-Type')
            .set("Access-Control-Allow-Methods", "GET")
            .set('Access-Control-Allow-Origin', '*');
        return this.http.get<comics[]>(this.apiURL, { headers: this.headers }).pipe(  
            
            tap(_ => this.log('get Comics')),
            catchError(this.handleError<comics[]>('getComics', []))
        );
    }

    private handleError<T>(operation = 'operation', result?: T) {
        return (error: any): Observable<T> => {

            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead

            // TODO: better job of transforming error for user consumption
            this.log(`${operation} failed: ${error.message}`);

            // Let the app keep running by returning an empty result.
            return of(result as T);
        };
    }

    /** Log a HeroService message with the MessageService */
    private log(message: string) {
        // this.messageService.add(`HeroService: ${message}`);
    }

}