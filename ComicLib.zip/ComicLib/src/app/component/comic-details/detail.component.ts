import { Component } from '@angular/core';
import { ComicService } from '../../service/app.service';
import { comics, Result } from '../../model/comice.model';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { elementAt } from 'rxjs/operators';

@Component({
    selector: 'comic-detail',
    templateUrl: './detail.component.html',
    providers: [ComicService]
})
export class DetailComponent {
    private retrivedata: Array<comics> = [];
    heroID: String = "";   
    comic: comics[];

    constructor(private comicService: ComicService, private route: ActivatedRoute) {
              
    }

    ngOnInit() {
        this.route.queryParams.subscribe(params => { this.heroID = params.id });
        if (this.heroID != "") {
            this.getHeroDetails(this.heroID)
        }
    }

    getHeroDetails(heroID) {
        this.comicService.getComics("Detail", heroID).subscribe((resComics) => {               
            this.comic = resComics["results"];
        });
    }

}