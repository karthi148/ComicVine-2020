import { Component,Input,Output ,EventEmitter } from '@angular/core';
import { ComicService } from '../../service/app.service';
import { comics } from '../../model/comice.model';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'comic-home',
  templateUrl: './home.component.html',
  providers:[ComicService]
})
export class HomeComponent {

    title = 'ComicLib';
    comics$: Observable<comics[]>;
    objComic=[];
    p: number = 1;
    pipes:['paginate'];
    findHero:string="";

    constructor(private comicService: ComicService, private route: ActivatedRoute,
        private router: Router) {
  
    }
  
    ngOnInit(): void {    
      this.getComics();
    }

    getComics() {
      this.comicService.getComics("Home","All").subscribe((resComics) => {
        this.p=0;
        this.objComic = resComics['results'];      
      });
    }
    
    redirectDetail(comic){     
           
        this.router.navigate(['/HeroDetails'],{ queryParams: { id: comic } });
    }

    searchHero(){
     
        this.comicService.getComics("Search",this.findHero).subscribe((resComics) => {
            this.p=0;
            this.objComic = resComics['results'];            
          });
    }
  
  
}